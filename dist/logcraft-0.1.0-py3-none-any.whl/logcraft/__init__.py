"""Logcraft: Craft changelogs from git commit history."""

__version__ = "0.1.0"
